from django.contrib import admin

# Register your models here.
from .models import Index
admin.site.register(Index)